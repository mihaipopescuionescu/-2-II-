package sensores;

/**
 * Clase que representa un sensor de sonido.
 * 
 * @author 
 */
public class SensorSonido extends SensorExterior {
    public SensorSonido(int id, float[] rango) {
        super(id, rango);
    }
}
