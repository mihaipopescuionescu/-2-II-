package sensores;

/**
 * Clase que representa un sensor de temperatura.
 * 
 * @author 
 */
public class SensorTemperatura extends SensorInterior {
    public SensorTemperatura(int id, float[] rango) {
        super(id, rango);
    }
}
