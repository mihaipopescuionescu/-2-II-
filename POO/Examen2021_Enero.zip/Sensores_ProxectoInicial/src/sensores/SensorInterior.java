package sensores;

/**
 * Clase que representa un sensor de interior genérico.
 * 
 * @author
 */
public class SensorInterior extends Sensor {
    public SensorInterior(int id, float[] rango) {
        super(id, rango);
    }
}
