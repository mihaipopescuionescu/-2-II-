package sensores;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Clase que representa un edificio.
 * 
 *  Los atributos de la clase son los siguientes:
 *      - id: identificador del edificio.
 *      - tipo: tipo de edificio, que puede ser de "viviendas" o de "oficionas".
 *      - plantas: conjunto de plantas del edificio.
 * 
 * @author 
 */
public class Edificio {
    private final int id;
    private String tipo;
    private HashMap<Integer,Planta> plantas;
    
    /**
     * a) Implementar el constructor para que reserve memoria e inicialice 
     *    correctamente los atributos de la clase.
     * 
     *    PUNTUACIÓN: -0,25 puntos si no está implementado o están implementado 
     *                de forma incorrecta.
     * 
     * @param id Identificador del edificio.
     * @param tipo Tipo del edificio (viviendas u oficinas).
     * 
     * @author 
     */
    public Edificio(int id, String tipo) {
        throw new UnsupportedOperationException();
    }
    
    /**
     * b) Dar de alta una planta en el edificio.
     * 
     *    PUNTUACIÓN: 0,4 puntos.
     * 
     * @param planta Planta que se dará de alta en el edificio.
     * 
     * @author 
     */
    public void altaPlanta(Planta planta) {
        throw new UnsupportedOperationException();
    }
    
    /**
     * c) Devolver el conjunto de sensores que han obtenido el mayor valor en las
     *    últimas 24 horas. 
     * 
     *    PUNTUACIÓN: 1,0 puntos.
     * 
     *    NOTA: los HashMap se deberán recorrer mediante un Iterator; si se recorren 
     *          con un for-each, se puntuará 0.
     * 
     * @return El conjunto de sensores que tienen el mayor valor en las últimas 
     *         24 horas. La función devuelve un conjunto de sensores porque puede 
     *         haber varios sensores con el mismo valor.
     * 
     * @author 
     */
    public ArrayList<Sensor> sensorValorSensores24h() {
        throw new UnsupportedOperationException();
    }
    
    /**
     * d) devolver las plantas del edificio que tienen un mayor número de sensores 
     *    estropeados.
     * 
     *    PUNTUACIÓN: 0,9 puntos.
     * 
     *    NOTA: los HashMap se deberán recorrer con un for-each sobre las claves; 
     *          si se recorren con un Iterator o sobre los valores, se puntuará 0.
     * 
     * @return El conjunto de plantas con un mayor número de sensores estropeados. 
     *         La función devuelve un conjunto de plantas porque puede haber varias 
     *         plantas que tengan el mismo número de sensores estropeados.
     * 
     * @author 
     */
    public ArrayList<Planta> plantaMasProblemas() {
        throw new UnsupportedOperationException();
    }
    
    /**
     * r) Devolver el conjunto de sensores de un determinado tipo que han obtenido 
     *    el valor máximo en las últimas 24 horas.
     * 
     *    PUNTUACIÓN: 1,2 puntos.
     * 
     * @param tipo El tipo de sensor que 
     * @return El conjunto de sensores que tienen el mismo valor en las últimas 
     *         24 horas. La función devuelve un conjunto de sensores porque puede 
     *         haber varios sensores con el mismo valor.
     * 
     * @author 
     */
    public ArrayList<Sensor> sensorValorSensores24h(String tipo) {
        throw new UnsupportedOperationException();
    }

    public int getId() {
        return id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        if(tipo.equals("Viviendas") || tipo.equals("Oficinas")) this.tipo= tipo;
        else this.tipo= "Oficinas";
    }

    public HashMap<Integer, Planta> getPlantas() {
        return plantas;
    }

    public void setPlantas(HashMap<Integer, Planta> plantas) {
        this.plantas = plantas;
    }
}
