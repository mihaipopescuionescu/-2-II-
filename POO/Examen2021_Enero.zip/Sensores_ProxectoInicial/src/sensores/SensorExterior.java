package sensores;

/**
 * Clase que representa un sensor de exterior genérico.
 * 
 * @author 
 */
public class SensorExterior extends Sensor {
    public SensorExterior(int id, float[] rango) {
        super(id, rango);
    }
}
