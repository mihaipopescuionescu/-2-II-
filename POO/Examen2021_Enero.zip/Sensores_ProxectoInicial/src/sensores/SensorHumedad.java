package sensores;

/**
 * Clase que representa un sensor de humedad.
 * 
 * @author 
 */
public class SensorHumedad extends SensorInterior {
    public SensorHumedad(int id, float[] rango) {
        super(id, rango);
    }
}
