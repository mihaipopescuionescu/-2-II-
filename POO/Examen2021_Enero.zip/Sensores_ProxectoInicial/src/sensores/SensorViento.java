package sensores;

/**
 * Clase que representa un sensor de viento.
 * 
 * @author 
 */
public class SensorViento extends SensorExterior {
    public SensorViento(int id, float[] rango) {
        super(id, rango);
    }
}
