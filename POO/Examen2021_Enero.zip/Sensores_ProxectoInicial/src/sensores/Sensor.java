package sensores;

import java.util.HashMap;

/**
 * Clase que representa un sensor genérico.
 * 
 *  Los atributos de la clase son los siguientes:
 *      - PRECIO_BASE: es el precio base de un sensor.
 *      - id: identificador del sensor.
 *      - precio: precio del sensor.
 *      - rango: es el rango de valores que puede tomar el sensor. Es un array de 
 *               tamaño 2, donde rango[0] es el valor mínimo y rango[1] es el valor 
 *               máximo que puede tomar el sensor
 *      - planta: planta en la que se encuentra el sensor.
 *      - valores: conjunto de valores obtenidos por el sensor, donde una entrada
 *                 del HashMap está formada por el instante de tiempo (clave) en  
 *                 el que se registra el valor (Float) del sensor. El instante de
 *                 tiempo se obtiene invocando al método System.currentTimeMillis().
 *      - estropeado: indica si un sensor está estropeado, en cuyo caso no puede
 *                    generar valores.
 * 
 * @author 
 */
public abstract class Sensor {
    private final Float PRECIO_BASE= 5.25f;
    private final int id;
    private final Float precio;
    private final Float[] rango;
    private Planta planta;
    private HashMap<Long,Float> valores;
    private boolean estropeado;
    
    /**
     * i) Implementar el constructor para que reserve memoria e inicialice 
     *    correctamente los atributos de la clase.
     * 
     *    PUNTUACIÓN: -0,25 puntos si no está implementado o están implementado 
     *                de forma incorrecta.
     * 
     * @param id Identificador del sensor.
     * @param rango Rango de valores que puede tomar el sensor.
     * 
     * @author
     */
    public Sensor(int id, float[] rango) {
        throw new UnsupportedOperationException();
    }
    
    /**
     * j) Almacenar un valor del sensor en la fecha actual.
     * 
     *    PUNTUACIÓN: 0,3 puntos.
     * 
     * @param valor El valor del sensor que se almacenará con la fecha actual.
     * 
     * @author
     */
    public void almacenarValor(Float valor) {
        throw new UnsupportedOperationException();
    }

    /**
     * k) Calcular el precio del sensor. Hay que tener en cuenta que si el sensor
     *    se instala en un edificio de viviendas el precio es un 20% mayor que el 
     *    precio base, mientras que si se instala en un edificio de oficinas será
     *    un 40% mayor que el precio base.
     * 
     *    PUNTUACIÓN: 0,3 puntos.
     * 
     * @return Devuelve el valor del precio del sensor.
     * 
     * @author
     */
    public float cacularPrecio() {
        throw new UnsupportedOperationException();
    }
    
    public int getId() {
        return id;
    }

    public HashMap<Long, Float> getValores() {
        return valores;
    }

    public Planta getPlanta() {
        return planta;
    }

    public Float getPrecio() {
        return precio;
    }

    public Float[] getRango() {
        return rango;
    }

    public boolean isEstropeado() {
        return estropeado;
    }

    public void setEstropeado(boolean estropeado) {
        this.estropeado = estropeado;
    }
    
    public void setValores(HashMap<Long, Float> valores) {
        this.valores = valores;
    }
    
    public Planta setPlanta(Planta planta) {
        return this.planta= planta;
    }
}