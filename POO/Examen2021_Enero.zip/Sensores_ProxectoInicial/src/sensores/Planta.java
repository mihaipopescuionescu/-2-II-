package sensores;

import java.util.HashMap;

/**
 * Clase que representa una planta.
 * 
 *  Los atributos de la clase son los siguientes:
 *      - id: identificador de la planta.
 *      - numero: número de la planta.
 *      - edificio: edificio en el que se encuentra la planta.
 *      - sensores: conjunto de sensores de la planta.
 * 
 * @author
 */
public class Planta {
    private final int id;
    private final int numero;
    private Edificio edificio;
    private HashMap<Integer,Sensor> sensores;
    
    /**
     * e) Implementar el constructor para que reserve memoria e inicialice 
     *    correctamente los atributos de la clase.
     * 
     *    PUNTUACIÓN: -0,25 puntos si no está implementado o están implementado 
     *                de forma incorrecta.
     * 
     * @param id Identificador de la planta.
     * @param numero Número de planta en el edificio al que pertenece.
     * 
     * @author 
     */
    public Planta(int id, int numero) {
        throw new UnsupportedOperationException();
    }
    

    /**
     * f) Dar de alta un sensor en la planta en la que estará instalado.
     * 
     *    PUNTUACIÓN: 0,4 puntos.
     * 
     * @param id Identificador del sensor.
     * @param rango Rango de valores que puede tomar el sensor.
     * 
     * @author 
     */
    public void altaSensor(int id, float[] rango) {
        throw new UnsupportedOperationException();
    }
    
    /**
     * g) Obtener el valor de todos los sensores en una fecha dada.
     * 
     *    PUNTUACIÓN: 0,9 puntos.
     * 
     *    NOTA: los HashMap se deberán recorrer con un Iterator sobre los valores;
     *          si se recorren con un for-each o sobre las claves, se puntuará 0.
     * 
     * @param fecha La fecha en la cual ocurren los valores de los sensores.
     * @return Se devuelve un HashMap donde la clave es el identificador de sensor 
     *         y el dato es su valor en la fecha dada.
     * 
     * @author 
     */
    public HashMap<String,Float> valoresSensores(Long fecha) {
        throw new UnsupportedOperationException();
    }

    /**
     * h) Indicar si existe una planta en el edificio cuyo coste es mayor que el 
     *    coste de la planta. El coste de la planta es la suma del precio de todos 
     *    los sensores de la planta.
     * 
     *    PUNTUACIÓN: 0,9 puntos.
     * 
     *    NOTA: los HashMap se deberán recorrer con un for-each; si se recorren 
     *          con un Iterator, se puntuará 0.
     * 
     * @return Se devuelve true si existe una planta con un coste mayor que la 
     *         planta actual.
     * 
     * @author 
     */
    public boolean plantaMasCara() {
        throw new UnsupportedOperationException();
    }
    
    /**
     * 
     * l) Escribir un valor para el sensor con el id dado.
     * 
     * @param id Indentificador del sensor.
     * @param valor El valor del sensor que se almacenará con la fecha actual.
     * 
     * @author 
     */
    public void escribirValor(int id, Float valor) {
        throw new UnsupportedOperationException();
    }
    
    public int getId() {
        return id;
    }

    public int getNumero() {
        return numero;
    }

    public Edificio getEdificio() {
        return edificio;
    }

    public HashMap<Integer, Sensor> getSensores() {
        return sensores;
    }

    public void setSensores(HashMap<Integer, Sensor> sensores) {
        this.sensores= sensores;
    }
    
    public void setEdificio(Edificio edificio) {
        this.edificio= edificio;
    }
}
