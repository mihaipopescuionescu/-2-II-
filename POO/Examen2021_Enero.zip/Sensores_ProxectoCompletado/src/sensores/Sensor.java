package sensores;

import java.util.HashMap;

/**
 * Clase que representa un sensor genérico.
 * 
 *  Los atributos de la clase son los siguientes:
 *      - PRECIO_BASE: es el precio base de un sensor.
 *      - id: identificador del sensor.
 *      - precio: precio del sensor.
 *      - rango: es el rango de valores que puede tomar el sensor. Es un array de 
 *               tamaño 2, donde rango[0] es el valor mínimo y rango[1] es el valor 
 *               máximo que puede tomar el sensor
 *      - planta: planta en la que se encuentra el sensor.
 *      - valores: conjunto de valores obtenidos por el sensor, donde una entrada
 *                 del HashMap está formada por el instante de tiempo (clave) en  
 *                 el que se registra el valor (Float) del sensor. El instante de
 *                 tiempo se obtiene invocando al método System.currentTimeMillis().
 *      - estropeado: indica si un sensor está estropeado, en cuyo caso no puede
 *                    generar valores.
 * 
 * @author 
 */
public class Sensor {
    private final Float PRECIO_BASE= 5.25f;
    private final int id;
    private Float precio;
    private final Float[] rango;
    private Planta planta;
    private HashMap<Long,Float> valores;
    private boolean estropeado;
    
    /**
     * i) Implementar el constructor para que reserve memoria e inicialice 
     *    correctamente los atributos de la clase.
     * 
     *    PUNTUACIÓN: -0,25 puntos si no está implementado o están implementado 
     *                de forma incorrecta.
     * 
     * @param id Identificador del sensor.
     * @param rango Rango de valores que puede tomar el sensor.
     * 
     * @author 
     */
    public Sensor(int id, float[] rango) {
        this.id = id;
        this.precio = this.PRECIO_BASE;
        this.rango = new Float[rango.length];
        for (int i = 0; i < rango.length; i++)
            this.rango[i] = rango[i];
        this.valores = new HashMap<>();
        this.estropeado = false;
    }
    
    public Sensor() {
        // Asígnanse valores por defecto
        this.id = 0;
        this.precio = this.PRECIO_BASE;
        this.rango = new Float[2];
        this.rango[0] = -50f;
        this.rango[1] = 50f;
        this.valores = new HashMap<>();
        this.estropeado = false;
        System.out.print("Creado un nuevo sensor con id " + this.id + ". ");
    }
    
    /**
     * j) Almacenar un valor del sensor en la fecha actual.
     * 
     *    PUNTUACIÓN: 0,3 puntos.
     * 
     * @param valor El valor del sensor que se almacenará con la fecha actual.
     * 
     * @author 
     */
    public void almacenarValor(Float valor) throws FueraRango, SensorEstropeado {
        if (valor < this.rango[0] || valor > this.rango[this.rango.length]) {
            throw new FueraRango("El valor " + valor + " está fuera del rango del sensor "
                    + "con id " + this.id + ".\n");
        }
        
        if (this.estropeado) {
            throw new SensorEstropeado("El sensor con id " + this.id + " está estropeado.\n");
        }
        
        this.valores.put(System.currentTimeMillis(), valor);
    }

    /**
     * k) Calcular el precio del sensor. Hay que tener en cuenta que si el sensor
     *    se instala en un edificio de viviendas el precio es un 20% mayor que el 
     *    precio base, mientras que si se instala en un edificio de oficinas será
     *    un 40% mayor que el precio base.
     * 
     *    PUNTUACIÓN: 0,3 puntos.
     * 
     * @return Devuelve el valor del precio del sensor.
     * 
     * @author 
     */
    public float cacularPrecio() {
        if (this.planta.getEdificio().getTipo().equals("Viviendas"))
            this.precio *= 1.2f;
     
        if (this.planta.getEdificio().getTipo().equals("Oficinas"))
            this.precio *= 1.4f;
        
        return this.precio;
    }
    
    public int getId() {
        return id;
    }

    public HashMap<Long, Float> getValores() {
        return valores;
    }

    public Planta getPlanta() {
        return planta;
    }

    public Float getPrecio() {
        return precio;
    }

    public Float[] getRango() {
        return rango;
    }

    public boolean isEstropeado() {
        return estropeado;
    }

    public void setEstropeado(boolean estropeado) {
        this.estropeado = estropeado;
    }
    
    public void setValores(HashMap<Long, Float> valores) {
        this.valores = valores;
    }
    
    public Planta setPlanta(Planta planta) {
        return this.planta= planta;
    }
    
}