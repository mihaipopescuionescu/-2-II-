package sensores;

/**
 *
 * @author
 */
public class SensorEstropeado extends Exception {
    
    public SensorEstropeado (String mensaje) {
        super(mensaje);
    }
}
