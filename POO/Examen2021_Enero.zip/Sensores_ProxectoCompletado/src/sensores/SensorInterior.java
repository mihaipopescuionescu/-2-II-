package sensores;

/**
 * Clase que representa un sensor de interior genérico.
 * 
 * @author 
 */
public class SensorInterior extends Sensor {
    
    public SensorInterior(int id, float[] rango) {
        super(id, rango);
    }
    
    public SensorInterior() {
        super();
        System.out.print("El sensor es para un edificio interior. ");
    }

    @Override
    public float cacularPrecio() {
        float resultado = super.cacularPrecio();
        resultado *= 1.25;
        return resultado;
    }
}
