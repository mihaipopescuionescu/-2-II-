package sensores;

/**
 * Clase que representa un sensor de viento.
 * 
 * @author 
 */
public class SensorViento extends SensorExterior {
    
    public SensorViento(int id, float[] rango) {
        super(id, rango);
    }
    
    public SensorViento() {
        super();
        System.out.println("Es un sensor de viento.");
    }
    
    @Override
    public float cacularPrecio() {
        float resultado = super.cacularPrecio();
        resultado *= 1.1;
        return resultado;
    }
}
