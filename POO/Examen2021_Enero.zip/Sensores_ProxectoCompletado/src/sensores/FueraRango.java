package sensores;

/**
 *
 * @author 
 */
public class FueraRango extends Exception {
    
    public FueraRango (String mensaje) {
        super(mensaje);
    }
}
