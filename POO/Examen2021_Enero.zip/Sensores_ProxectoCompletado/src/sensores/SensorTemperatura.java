package sensores;

/**
 * Clase que representa un sensor de temperatura.
 * 
 * @author 
 */
public final class SensorTemperatura extends SensorInterior {
    
    public SensorTemperatura(int id, float[] rango) {
        super(id, rango);
    }
    
    public SensorTemperatura() {
        super();
        System.out.println("Es un sensor de temperatura.");
    }
    
    @Override
    public float cacularPrecio() {
        float resultado = super.cacularPrecio();
        resultado *= 1.1;
        return resultado;
    }
}
