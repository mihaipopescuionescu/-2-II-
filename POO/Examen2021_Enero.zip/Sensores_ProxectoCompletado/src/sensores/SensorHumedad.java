package sensores;

/**
 * Clase que representa un sensor de humedad.
 * 
 * @author 
 */
public final class SensorHumedad extends SensorInterior {
    
    public SensorHumedad(int id, float[] rango) {
        super(id, rango);
    }
    
    public SensorHumedad() {
        super();
        System.out.println("Es un sensor de humedad.");
    }
    
    @Override
    public float cacularPrecio() {
        float resultado = super.cacularPrecio();
        resultado *= 1.15;
        return resultado;
    }
}
