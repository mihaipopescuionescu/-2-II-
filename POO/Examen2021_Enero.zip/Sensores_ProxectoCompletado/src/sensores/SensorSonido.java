package sensores;

/**
 * Clase que representa un sensor de sonido.
 * 
 * @author 
 */
public class SensorSonido extends SensorExterior {
    
    public SensorSonido(int id, float[] rango) {
        super(id, rango);
    }
    
    public SensorSonido() {
        super();
        System.out.println("Es un sensor de sonido.");
    }
    
    @Override
    public float cacularPrecio() {
        float resultado = super.cacularPrecio();
        resultado *= 1.2;
        return resultado;
    }
}
