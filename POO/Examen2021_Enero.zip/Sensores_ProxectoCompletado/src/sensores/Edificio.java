package sensores;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/**
 * Clase que representa un edificio.
 * 
 *  Los atributos de la clase son los siguientes:
 *      - id: identificador del edificio.
 *      - tipo: tipo de edificio, que puede ser de "viviendas" o de "oficionas".
 *      - plantas: conjunto de plantas del edificio.
 * 
 * @author 
 */
public class Edificio {
    private final int id;
    private String tipo;
    private HashMap<Integer,Planta> plantas;
    
    /**
     * a) Implementar el constructor para que reserve memoria e inicialice 
     *    correctamente los atributos de la clase.
     * 
     *    PUNTUACIÓN: -0,25 puntos si no está implementado o están implementado 
     *                de forma incorrecta.
     * 
     * @param id Identificador del edificio.
     * @param tipo Tipo del edificio (viviendas u oficinas).
     * 
     * @author 
     */
    public Edificio(int id, String tipo) {
        this.id = id;
        this.tipo = tipo;
        this.plantas = new HashMap<>();
    }
    
    /**
     * b) Dar de alta una planta en el edificio.
     * 
     *    PUNTUACIÓN: 0,4 puntos.
     * 
     * @param planta Planta que se dará de alta en el edificio.
     * 
     * @author 
     */
    public void altaPlanta(Planta planta) {
        if (!this.plantas.containsKey(planta.getId())) {
            planta.setEdificio(this);
            this.plantas.put(planta.getId(), planta);
        }
        else
            System.out.println("A planta xa está dada de alta neste edificio.");
    }
    
    /**
     * c) Devolver el conjunto de sensores que han obtenido el mayor valor en las
     *    últimas 24 horas. 
     * 
     *    PUNTUACIÓN: 1,0 puntos.
     * 
     *    NOTA: los HashMap se deberán recorrer mediante un Iterator; si se recorren 
     *          con un for-each, se puntuará 0.
     * 
     * @return El conjunto de sensores que tienen el mayor valor en las últimas 
     *         24 horas. La función devuelve un conjunto de sensores porque puede 
     *         haber varios sensores con el mismo valor.
     * 
     * @author 
     */
    public ArrayList<Sensor> sensorValorSensores24h() {
        ArrayList<Sensor> resultado = new ArrayList<>();
        float maxValor = 0f;
        Long difData;
        
        Iterator<Planta> it1;
        Iterator<Sensor> it2;
        Iterator<Long> it3K;
        Iterator<Float> it3V;
        Planta pActual;
        Sensor sActual;
        float vActual;
        Long fActual;
        
        // Neste bucle búscase o valor máximo
        it1 = this.plantas.values().iterator();
        while (it1.hasNext()) {
            pActual = it1.next();
            it2 = pActual.getSensores().values().iterator();
            while (it2.hasNext()) {
                sActual = it2.next();
                it3K = sActual.getValores().keySet().iterator();
                while (it3K.hasNext()) {
                    fActual = it3K.next();
                    vActual = sActual.getValores().get(fActual);
                    difData = System.currentTimeMillis() - fActual;
                    if ((vActual > maxValor) && (difData < 24*60*60*1000))
                        maxValor = vActual;
                }
            }
        }
        
        // Neste bucle gárdanse os sensores con ese máximo no resultado
        it1 = this.plantas.values().iterator();
        while (it1.hasNext()) {
            pActual = it1.next();
            it2 = pActual.getSensores().values().iterator();
            while (it2.hasNext()) {
                sActual = it2.next();
                it3V = sActual.getValores().values().iterator();
                while (it3V.hasNext()) {
                    vActual = it3V.next();
                    if (vActual == maxValor)
                        resultado.add(sActual);
                }
            }
        }
        
        return resultado;
    }
    
    /**
     * d) devolver las plantas del edificio que tienen un mayor número de sensores 
     *    estropeados.
     * 
     *    PUNTUACIÓN: 0,9 puntos.
     * 
     *    NOTA: los HashMap se deberán recorrer con un for-each sobre las claves; 
     *          si se recorren con un Iterator o sobre los valores, se puntuará 0.
     * 
     * @return El conjunto de plantas con un mayor número de sensores estropeados. 
     *         La función devuelve un conjunto de plantas porque puede haber varias 
     *         plantas que tengan el mismo número de sensores estropeados.
     * 
     * @author 
     */
    public ArrayList<Planta> plantaMasProblemas() {
        ArrayList<Planta> resultado = new ArrayList<>();
        int maxAbs = 0;
        int maxPlanta;
        
        Planta pActual;
        Sensor sActual;
        
        // Neste bucle búscase o valor máximo
        for (Integer kPlanta : this.plantas.keySet()) {
            maxAbs = 0;
            pActual = this.plantas.get(kPlanta);
            for (Integer kSensor : pActual.getSensores().keySet()) {
                sActual = pActual.getSensores().get(kSensor);
                if (sActual.isEstropeado())
                    maxAbs++;
            }
        }
        
        // Neste bucle gárdanse as plantas con ese máximo no resultado
        for (Integer kPlanta : this.plantas.keySet()) {
            maxPlanta = 0;
            pActual = this.plantas.get(kPlanta);
            for (Integer kSensor : pActual.getSensores().keySet()) {
                sActual = pActual.getSensores().get(kSensor);
                if (sActual.isEstropeado())
                    maxPlanta++;
            }
            if (maxPlanta == maxAbs)
                resultado.add(pActual);
        }
        
        return resultado;
    }
    
    /**
     * r) Devolver el conjunto de sensores de un determinado tipo que han obtenido 
     *    el valor máximo en las últimas 24 horas.
     * 
     *    PUNTUACIÓN: 1,2 puntos.
     * 
     * @param tipo El tipo de sensor que 
     * @return El conjunto de sensores que tienen el mismo valor en las últimas 
     *         24 horas. La función devuelve un conjunto de sensores porque puede 
     *         haber varios sensores con el mismo valor.
     * 
     * @author 
     */
    public ArrayList<Sensor> sensorValorSensores24h(String tipo) {
        /*
            É unha copia do método do apartado c, só que engadindo unha condición
            antes de explorar o valor de cada sensor.
        */
        
        ArrayList<Sensor> resultado = new ArrayList<>();
        float maxValor = 0f;
        Long difData;
        boolean condicionTipo;
        
        Iterator<Planta> it1;
        Iterator<Sensor> it2;
        Iterator<Long> it3K;
        Iterator<Float> it3V;
        Planta pActual;
        Sensor sActual;
        float vActual;
        Long fActual;
        
        // Neste bucle búscase o valor máximo
        it1 = this.plantas.values().iterator();
        while (it1.hasNext()) {
            pActual = it1.next();
            it2 = pActual.getSensores().values().iterator();
            while (it2.hasNext()) {
                sActual = it2.next();
                it3K = sActual.getValores().keySet().iterator();
                
                condicionTipo = isTipo(sActual, tipo); // A nova condición
                
                while (it3K.hasNext() && condicionTipo) {
                    fActual = it3K.next();
                    vActual = sActual.getValores().get(fActual);
                    difData = System.currentTimeMillis() - fActual;
                    if ((vActual > maxValor) && (difData < 24*60*60*1000))
                        maxValor = vActual;
                }
            }
        }
        
        // Neste bucle gárdanse os sensores con ese máximo no resultado
        it1 = this.plantas.values().iterator();
        while (it1.hasNext()) {
            pActual = it1.next();
            it2 = pActual.getSensores().values().iterator();
            while (it2.hasNext()) {
                sActual = it2.next();
                it3V = sActual.getValores().values().iterator();
                
                condicionTipo = isTipo(sActual, tipo); // A nova condición
                
                while (it3V.hasNext() && condicionTipo) {
                    vActual = it3V.next();
                    if (vActual == maxValor)
                        resultado.add(sActual);
                }
            }
        }
        
        return resultado;
    }
    
    // Método auxiliar
    private boolean isTipo(Sensor s, String tipo) {
        switch(tipo) {
            case "Exterior":
                return s instanceof SensorExterior;
            case "Interior":
                return s instanceof SensorInterior;
            case "Humedad":
                return s instanceof SensorHumedad;
            case "Sonido":
                return s instanceof SensorSonido;
            case "Temperatura":
                return s instanceof SensorTemperatura;
            case "Viento":
                return s instanceof SensorViento;
            default:
                System.out.println("Non debería chegar a aquí");
                return false;
        }
    }

    public int getId() {
        return id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        if(tipo.equals("Viviendas") || tipo.equals("Oficinas")) this.tipo= tipo;
        else this.tipo= "Oficinas";
    }

    public HashMap<Integer, Planta> getPlantas() {
        return plantas;
    }

    public void setPlantas(HashMap<Integer, Planta> plantas) {
        this.plantas = plantas;
    }
}
