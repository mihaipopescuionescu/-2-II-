package sensores;

/**
 * Clase que representa un sensor de exterior genérico.
 * 
 * @author 
 */
public class SensorExterior extends Sensor {
    
    public SensorExterior(int id, float[] rango) {
        super(id, rango);
    }
    
    public SensorExterior() {
        super();
        System.out.print("El sensor es para un edificio exterior. ");
    }
    
    @Override
    public float cacularPrecio() {
        float resultado = super.cacularPrecio();
        resultado *= 1.5;
        return resultado;
    }
}
