package Paquete;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public final class Estudiante {

    private String nombre;
    private IGrado grado;
    private ArrayList<String> asignaturas;
    private ArrayList<Float> notas;

    public Estudiante(String nombre, Grado grado) {
        setNombre(nombre);
        setGrado(grado);
        setAsignaturas(new ArrayList<String>());
        setNotas(new ArrayList<Float>());
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre != null) {
            this.nombre = nombre;
        }
    }

    public IGrado getGrado() {
        return grado;
    }

    public void setGrado(IGrado grado) {
        if (grado != null) {
            this.grado = grado;
        }
    }

    public ArrayList<String> getAsignaturas() {
        return asignaturas;
    }

    public void setAsignaturas(ArrayList<String> asignaturas) {
        if (asignaturas != null) {
            this.asignaturas = asignaturas;
        }
    }

    public ArrayList<Float> getNotas() {
        return notas;
    }

    public void setNotas(ArrayList<Float> notas) {
        if (notas != null) {
            this.notas = notas;
        }
    }

    public void darAltaAsignatura(String asignatura, Float nota) {
        if (asignatura != null && nota >= 0) {
            this.asignaturas.add(asignatura);
            this.notas.add(nota);
        }
    }

    public Float notaMedia() {
        float media = 0;
        for (Float nota : this.notas) {
            media += nota;
        }
        media /= this.notas.size();
        return media;
    }

    public ArrayList<String> asignaturasMinimaNota(Float nota) {
        ArrayList<String> asignaturasSeleccionadas = new ArrayList<>();
        if (nota >= 0) {
            for (String asig : this.asignaturas) {
                if (this.notas.get(this.asignaturas.indexOf(asig)) >= nota) {
                    asignaturasSeleccionadas.add(asig);
                }
            }
        }
        return asignaturasSeleccionadas;
    }

    public void estudiantesMayorNota() {
        Float media = this.notaMedia();
        int bandera = 0;

        Collection<Estudiante> aux = this.grado.getEstudiantes().values();
        Iterator<Estudiante> it = aux.iterator();
        while (it.hasNext()) {
            Estudiante est = it.next();
            if (est.notaMedia() > media) {
                System.out.println(est.getNombre());
                bandera = 1;
            }
        }
        if (bandera == 0) {
            System.out.println("No hay estudiantes con nota media superior");
        }
    }
}
