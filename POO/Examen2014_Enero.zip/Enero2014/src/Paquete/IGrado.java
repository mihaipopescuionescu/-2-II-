package Paquete;

import java.util.HashMap;

public interface IGrado {

    public void darAlta(Estudiante estudiante) throws ExcepcionMaximosEstudiantes;

    public void darAlta(String nombre) throws ExcepcionMaximosEstudiantes;

    public boolean estarMatriculado(Estudiante estudiante);

    public boolean estarMatriculado(String nombre);

    public HashMap<String, Estudiante> estudiantesAsignatura(String asignatura);

    public int numeroProfesoresGrado();

    public HashMap<String, Estudiante> getEstudiantes();
}
