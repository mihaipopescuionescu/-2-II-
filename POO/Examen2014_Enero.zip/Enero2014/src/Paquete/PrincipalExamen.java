package Paquete;

import java.util.ArrayList;
import java.util.HashMap;

public class PrincipalExamen {

    public static void main(String[] args) {

        // PRUEBAS GRADO
        Grado gradoPrueba = new Grado("politicas", 150); // instanciamos un grado

        System.out.println(gradoPrueba.getNombre()); // mostramos los atributos
        System.out.println(gradoPrueba.getNumeroProfesores());
        System.out.println(gradoPrueba.getMaximosEstudiantes());
        System.out.println(gradoPrueba.getEstudiantes());

        gradoPrueba.setNombre("politicasAvanzadas"); // cambiamos los atributos
        gradoPrueba.setMaximosEstudiantes(160);
        gradoPrueba.setNumeroProfesores(2);
        HashMap<String, Estudiante> estudiantes = new HashMap<>();

        Estudiante est = new Estudiante("Juan", gradoPrueba);

        estudiantes.put(est.getNombre(), est);
        gradoPrueba.setEstudiantes(estudiantes);

        System.out.println(gradoPrueba.getNombre()); // volvemos a mostrar los atributos modificados
        System.out.println(gradoPrueba.getNumeroProfesores());
        System.out.println(gradoPrueba.getMaximosEstudiantes());
        System.out.println(gradoPrueba.getEstudiantes());

        Grado gradoPrueba2 = new Grado("fisica", 200); // creamos otro grado
        try {
            gradoPrueba2.darAlta(est); // función dar de alta
        } catch (ExcepcionMaximosEstudiantes e) {
            e.incrementar();
        }

        System.out.println(gradoPrueba2.getNombre());   // mostramos los atributos
        System.out.println(gradoPrueba2.getNumeroProfesores());
        System.out.println(gradoPrueba2.getMaximosEstudiantes());
        System.out.println(gradoPrueba2.getEstudiantes().size()); // número de estudiantes
        try {   // Función dar de alta que usa string
            gradoPrueba2.darAlta("Jose");
        } catch (ExcepcionMaximosEstudiantes e) {
            e.incrementar();
        }

        if (gradoPrueba2.estarMatriculado(est)) { // funcion estar matriculado
            System.out.println("Si");
        }

        if (gradoPrueba2.estarMatriculado("Jose")) { // funcion estar matriculado que usa string
            System.out.println("Si");
        }

        est.darAltaAsignatura("calculo", 6F);
        System.out.println(gradoPrueba2.estudiantesAsignatura("calculo")); // funcion estudiantes con la asignatura dada

        System.out.println(gradoPrueba2.numeroProfesoresGrado()); // funcion numero de profesores

        System.out.println("__________________________________________");

        // PRUEBAS ESTUDIANTE
        Estudiante est2 = new Estudiante("Luis", gradoPrueba2); // creamos un segundo estudiantes

        System.out.println(est2.getNombre()); // mostramos los atributos
        System.out.println(((Grado) est2.getGrado()).getNombre());
        System.out.println(est2.getAsignaturas());
        System.out.println(est2.getNotas());

        est2.setNombre("Juan Antonio"); // cambiamos los atributos
        ArrayList<String> asig = new ArrayList<>();
        asig.add("Fisica");
        asig.add("Optica");
        est2.setGrado(gradoPrueba2);
        est2.setAsignaturas(asig);
        ArrayList<Float> not = new ArrayList<>();
        not.add(3F);
        not.add(6F);
        est2.setNotas(not);

        System.out.println(est2.getNombre()); // mostramos los atributos modificados
        System.out.println(((Grado) est2.getGrado()).getNombre());
        System.out.println(est2.getAsignaturas());
        System.out.println(est2.getNotas());

        est2.darAltaAsignatura("Algebra", 8F); // añadimos una tercera asignatura y mostramos asignaturas y notas como en el caso anterior
        System.out.println(est2.getAsignaturas());
        System.out.println(est2.getNotas());

        System.out.println(est2.notaMedia()); // calculamos la nota media
        System.out.println(est2.asignaturasMinimaNota(7F)); // mostramos las asignaturas con nota inferior a 7

        // est.darAltaAsignatura("Fisica", 5F);
        // est2.estudiantesMayorNota();
        est.darAltaAsignatura("Fisica", 9F);
        est2.estudiantesMayorNota(); // mostramos los estudiantes con nota mayor (est, porque tiene un 9)

        System.out.println("____________________________________");

        // EXCEPCION
        Grado grado3 = new Grado("Matematicas", 1); // estudiantes máximos 1
        try {
            grado3.darAlta(est); // añadimos un estudiante
        } catch (ExcepcionMaximosEstudiantes e) {
            e.incrementar();
        }

        System.out.println(grado3.getEstudiantes().size());

        try {
            grado3.darAlta(est2); // intentamos añadir el segundo
        } catch (ExcepcionMaximosEstudiantes e) { // salta la excepcion y se incrementa en 10 (11 max)
            e.incrementar(); // al incrementarse la primera vez se establece a 1 la bandera que indica que no se podrá incrementar en una nueva ocasión
            try {
                grado3.darAlta(est2); // se añade correctamente porque el nuevo máximo es 11
            } catch (ExcepcionMaximosEstudiantes ex) {
                ex.incrementar();
            }
        }
        System.out.println(grado3.getEstudiantes().size());

        System.out.println("______________________________");

        // JERARQUÍA       
        Grado ingsoft = new Grado("Ingenieria Software", 60); // del nivel 0
        IngenieriaInformatica inginf = new IngenieriaInformatica("Ingenieria Informatiaca", 50); // del nivel 2     

        // Instancio dos clases de la jerarquía de dos niveles distitno. Una instancia del nivel raíz y otra del segundo nivel. 
        // El nivel intermedio no es instanciable.
    }
}
