package Paquete;

public abstract class Computacion extends Grado {

    public Computacion(String nombre, int maximosEstudiantes) {
        super(nombre, maximosEstudiantes);
    }

    @Override
    public int numeroProfesoresGrado() { 
        if (this.getEstudiantes().size() > 0) {
            if (this.getEstudiantes().size() > 30) {
                setNumeroProfesores(this.getEstudiantes().size() / 10);
                return this.getEstudiantes().size() / 10;
            } else {
                setNumeroProfesores(1);
                return 1;
            }
        }
        return 0;
    }
}
