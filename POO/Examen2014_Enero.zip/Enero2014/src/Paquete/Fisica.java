package Paquete;

public final class Fisica extends Ciencia {

    public Fisica(String nombre, int maximosEstudiantes) {
        super(nombre, maximosEstudiantes);
    }

    @Override
    public int numeroProfesoresGrado() { 
        if (this.getEstudiantes().size() > 0) {
            if (this.getEstudiantes().size() > 60) {
                setNumeroProfesores(this.getEstudiantes().size() / 10);
                return this.getEstudiantes().size() / 10;
            } else {
                setNumeroProfesores(1);
                return 1;
            }
        }
        return 0;
    }
}
