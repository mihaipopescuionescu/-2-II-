package Paquete;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

/*
 * Se crean las subclases de Grado: Computacion y Ciencia. Estas dos clases son 
 * de tipo abstracto, puesto que no tiene sentido instanciarlas. Es decir, no
 * existe un grado Computacion ni un grado Ciencia, sin embargo, nos ayudan
 * a identificar a los tipos de grado que sí existen y se pueden instanciar.
 * La clase Computacion es padre de IngenieraInformatica y de 
 * IngenieriaTelecomunicaciones. La clase Ciencia es padre de las clases
 * Fisica y Quimica. Estas últimas cuatro clases (las clases hoja), las del 
 * último nivel de la jerarquía, son de tipo final. Es decir, no van a poder
 * ser padres de otras clases. Son grados que existen y no existen subgrados 
 * de los mismos. 
 * La clase Raíz Grado es instanciable para poder hacer las primeras pruebas.
 * Además, si queremos instanciar uno de los grados que no estén implementados
 * podemos hacerlo instanciando la clase Grado.
 */
public class Grado implements IGrado {

    private int aumento;
    private String nombre;
    private HashMap<String, Estudiante> estudiantes;
    private int numeroProfesores;
    private int maximosEstudiantes;

    public Grado(String nombre, int maximosEstudiantes) {
        setAumento(0);
        setNombre(nombre);
        setMaximosEstudiantes(maximosEstudiantes);
        setEstudiantes(new HashMap<String, Estudiante>());
        setNumeroProfesores(this.numeroProfesoresGrado());
    }

    public int getAumento() {
        return aumento;
    }

    public void setAumento(int aumento) {
        if (aumento == 0 || aumento == 1) {
            this.aumento = aumento;
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre != null) {
            this.nombre = nombre;
        }
    }

    @Override
    public HashMap<String, Estudiante> getEstudiantes() {
        return estudiantes;
    }

    public void setEstudiantes(HashMap<String, Estudiante> estudiantes) {
        if (estudiantes != null) {
            this.estudiantes = estudiantes;
        }
    }

    public int getNumeroProfesores() {
        return numeroProfesores;
    }

    public void setNumeroProfesores(int numeroProfesores) {
        if (numeroProfesores >= 0) {
            this.numeroProfesores = numeroProfesores;
        }
    }

    public int getMaximosEstudiantes() {
        return maximosEstudiantes;
    }

    public void setMaximosEstudiantes(int maximosEstudiantes) {
        if (maximosEstudiantes >= 0) {
            this.maximosEstudiantes = maximosEstudiantes;
        }
    }

    @Override
    public void darAlta(Estudiante estudiante) throws ExcepcionMaximosEstudiantes {
        if (estudiante != null) {
            if (this.estudiantes.size() < this.maximosEstudiantes) {
                this.estudiantes.put(estudiante.getNombre(), estudiante);
                estudiante.setGrado(this);
                numeroProfesoresGrado();
            } else {
                throw new ExcepcionMaximosEstudiantes(this);
            }
        }
    }

    @Override
    public void darAlta(String nombre) throws ExcepcionMaximosEstudiantes {
        if (nombre != null) {
            if (this.estudiantes.size() < this.maximosEstudiantes) {
                if (!this.estudiantes.containsKey(nombre)) {
                    Estudiante est = new Estudiante(nombre, this);
                    this.estudiantes.put(nombre, est);
                    est.setGrado(this);
                    numeroProfesoresGrado();
                } else {
                    throw new ExcepcionMaximosEstudiantes(this);
                }
            }
        }
    }

    @Override
    public boolean estarMatriculado(Estudiante estudiante) {
        if (estudiante != null) {
            if (this.estudiantes.containsValue(estudiante)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean estarMatriculado(String nombre) {
        if (nombre != null) {
            if (this.estudiantes.containsKey(nombre)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public HashMap<String, Estudiante> estudiantesAsignatura(String asignatura) {
        HashMap<String, Estudiante> seleccionados = new HashMap<>();
        if (asignatura != null) {
            Collection<Estudiante> aux = this.estudiantes.values();
            Iterator<Estudiante> it = aux.iterator();
            while (it.hasNext()) {
                Estudiante est = it.next();
                if (est.getAsignaturas().contains(asignatura)) {
                    seleccionados.put(est.getNombre(), est);
                }
            }
        }
        return seleccionados;
    }

    @Override
    public int numeroProfesoresGrado() {
        if (this.getEstudiantes().size() > 0) {
            if (this.getEstudiantes().size() >= 10) {
                setNumeroProfesores(this.getEstudiantes().size() / 10);
                return this.getEstudiantes().size() / 10;
            } else {
                setNumeroProfesores(1);
                return 1;
            }
        }
        return 0;
    }
}
