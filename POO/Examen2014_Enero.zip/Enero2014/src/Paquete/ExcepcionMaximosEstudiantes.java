package Paquete;

public class ExcepcionMaximosEstudiantes extends Exception {

    private Grado grado;

    public ExcepcionMaximosEstudiantes(Grado grado) {
        super("Número máximo de estudiantes");
        setGrado(grado);
    }

    private void setGrado(Grado grado) {
        if (grado != null) {
            this.grado = grado;
        }
    }

    public void incrementar() {
        System.out.println("Número máximo de estudiantes");
        if (this.grado.getAumento() == 0) {
            this.grado.setMaximosEstudiantes(this.grado.getMaximosEstudiantes() + 10);
            this.grado.setAumento(1);
            System.out.println("Se ha incrementado el número máximo en 10 estudiantes");
        } else {
            System.out.println("No se puede incrementar el número de estudiantes más de una vez");
        }
    }
}
