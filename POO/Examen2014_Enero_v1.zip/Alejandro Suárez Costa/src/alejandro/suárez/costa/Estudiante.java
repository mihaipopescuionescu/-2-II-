/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package alejandro.suárez.costa;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author w7ttzzn319nvpi000071
 */
public class Estudiante {
    private String nombre;
    private IGrado grado;
    private HashMap<String,Float> ListaAsignaturas;

    public Estudiante() {
        nombre=null;
        grado=null;
        ListaAsignaturas=new HashMap<String,Float>();
    }

    public Estudiante(String nombre, IGrado grado) {
        setNombre(nombre);
        setGrado(grado);
        ListaAsignaturas=new HashMap<String,Float>();
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setGrado(IGrado grado) {
        try {
            grado.DarAltaEstudiante(this);
        } catch (ExcepcionMaximoEstudiantes ex) {
            ex.TratamientoExcepcion();
        }
        this.grado = grado;
    }

    public void setListaAsignaturas(HashMap<String, Float> ListaAsignaturas) {
        this.ListaAsignaturas = ListaAsignaturas;
    }

    public String getNombre() {
        return nombre;
    }

    public IGrado getGrado() {
        return grado;
    }

    public HashMap<String, Float> getListaAsignaturas() {
        return ListaAsignaturas;
    }
    
    public void DarAltaAsignatura(String nombreAsignatura, Float nota){
        ListaAsignaturas.put(nombreAsignatura, (Float)nota);
    }
    public float NotaMediaAsignaturas(){
        float Media=0;
        int contador=0;
        Iterator iterator=ListaAsignaturas.values().iterator();
        while(iterator.hasNext()){
            Float nota=(Float) iterator.next();
            Media=nota+Media;
            contador++;
        }
        Media=Media/contador;
        return Media;
        
    }
    public ArrayList<String> ConjuntoAsignaturasMayorNota(float Valor){
        ArrayList<String> conjuntoAsignaturas=new ArrayList<>();
        Iterator iterator=ListaAsignaturas.keySet().iterator();
        while(iterator.hasNext()){
            String keyset=(String) iterator.next();
            if(ListaAsignaturas.get(keyset)>Valor){
                conjuntoAsignaturas.add(keyset);
            }
        }
        return conjuntoAsignaturas;
    }
    public boolean ExisteEstudianteSuperior(Grado grado){
        for(Estudiante estudiante:grado.getConjuntoEstudiantes().values()){
            if (estudiante.NotaMediaAsignaturas()>this.NotaMediaAsignaturas()){
                return true;
            }
        }
        
        return false;
        
    }
    
    
    
}
