/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package alejandro.suárez.costa;

/**
 *
 * @author w7ttzzn319nvpi000071
 */
public final class IngenieriaInformatica extends Ciencias{

    public IngenieriaInformatica() {
        super();
    }

    public IngenieriaInformatica(String nombre, int numeroMaximoEtudiantes) {
        super(nombre, numeroMaximoEtudiantes);
    }
    
    @Override
    public int NumeroProfesoresGrado(){
        return super.NumeroProfesoresGrado()*2;
        
    }
    
}
