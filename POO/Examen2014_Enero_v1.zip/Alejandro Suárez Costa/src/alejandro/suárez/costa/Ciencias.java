/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package alejandro.suárez.costa;

/**
 *
 * @author w7ttzzn319nvpi000071
 */
public class Ciencias extends Grado{

    public Ciencias() {
        super();
    }

    public Ciencias(String nombre, int numeroMaximoEtudiantes) {
        super(nombre, numeroMaximoEtudiantes);
    }
    
}
