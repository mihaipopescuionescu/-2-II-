/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package alejandro.suárez.costa;

/**
 *
 * @author w7ttzzn319nvpi000071
 */
public abstract class Letras extends Grado{

    public Letras() {
        super();
    }

    public Letras(String nombre, int numeroMaximoEtudiantes) {
        super(nombre, numeroMaximoEtudiantes);
    }
    
    
}
