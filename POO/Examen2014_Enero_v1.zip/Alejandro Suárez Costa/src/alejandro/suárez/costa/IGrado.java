/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package alejandro.suárez.costa;

import java.util.ArrayList;

/**
 *
 * @author w7ttzzn319nvpi000071
 */
public interface IGrado {
    
     public void DarAltaEstudiante(Estudiante estudiante) throws ExcepcionMaximoEstudiantes;
     public void DarAltaEstudiante(String nombre,Grado grado);
     public boolean EsEstudianteGrado(Estudiante estudiante);
     public boolean EsEstudianteGrado(String nombre);
     public ArrayList<Estudiante> ListaEstudianteAsignatura(String asignatura);
     public int NumeroProfesoresGrado();
    
}
