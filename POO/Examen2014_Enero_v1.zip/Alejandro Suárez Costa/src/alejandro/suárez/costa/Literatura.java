/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package alejandro.suárez.costa;

/**
 *
 * @author w7ttzzn319nvpi000071
 */
public final class Literatura extends Letras{

    public Literatura() {
    }

    public Literatura(String nombre, int numeroMaximoEtudiantes) {
        super(nombre, numeroMaximoEtudiantes);
    }
    
    @Override
    public int NumeroProfesoresGrado(){
        return super.NumeroProfesoresGrado()*4;
    }
    
}
