/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package alejandro.suárez.costa;

/**
 *
 * @author w7ttzzn319nvpi000071
 */
public class ExcepcionMaximoEstudiantes extends Exception {
    Estudiante estudiante;
    Grado grado;
    public ExcepcionMaximoEstudiantes(Estudiante student, Grado grado){
        estudiante=student;
        this.grado=grado;
        
        System.out.println("Se ha sobrepasado el maximo estudiantes a matricular");
    }
    public void TratamientoExcepcion(){
        System.out.println("Numero maximo alumnos grado incrementado en 10");
        grado.setNumeroMaximoEstudiantes(grado.getNumeroMaximoEstudiantes()+10);
        try{
            grado.DarAltaEstudiante(estudiante);
        }
        catch(ExcepcionMaximoEstudiantes ex){
            if(grado.getNumeroMaximoEstudiantes()>=grado.NumeroEstudiantesGrado()){
                System.out.println("Numero estudiantes superado");
            }
            else{
            ex.TratamientoExcepcion();
            }
        }
    }
    
}
