/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package alejandro.suárez.costa;

/**
 *
 * @author w7ttzzn319nvpi000071
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        float a = 1;
        float b = 5;
        float c = 8;
        Grado grado1=new  Matematicas("Mates",25);
        Grado grado2=new  Historia("Hist",25);
        Grado grado3=new  Literatura("Lit",25);
        Grado grado4=new  IngenieriaInformatica("IngI",25);
        
        
        Estudiante estudiante1=new Estudiante("pepe1",grado1);
        estudiante1.DarAltaAsignatura("asignatura1", a);
        estudiante1.DarAltaAsignatura("asignatura2",b);
        estudiante1.DarAltaAsignatura("asignatura3",c);
        System.out.println(grado1.getNumeroProfesores());
        System.out.println(grado1.getNumeroMaximoEstudiantes());
        System.out.println(grado1.getConjuntoEstudiantes());
        System.out.println(estudiante1.NotaMediaAsignaturas());
        System.out.println(estudiante1.ExisteEstudianteSuperior(grado4));
        Estudiante estudiante2=new Estudiante("pepe2",grado1);
        Estudiante estudiante3=new Estudiante("pepe3",grado4);
        Estudiante estudiante4=new Estudiante("pepe4",grado4);
        Estudiante estudiante5=new Estudiante("pepe5",grado4);
        
        //No me dio tiempo a probar algunos metodos
        
    }
}
