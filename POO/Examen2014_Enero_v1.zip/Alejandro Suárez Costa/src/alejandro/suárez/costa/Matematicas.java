/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package alejandro.suárez.costa;

/**
 *
 * @author w7ttzzn319nvpi000071
 */
public final class Matematicas extends Ciencias{

    public Matematicas() {
        super();
    }

    public Matematicas(String nombre,int numEstudiantes) {
        super(nombre,numEstudiantes);
    }
    @Override
    public int NumeroProfesoresGrado(){
        return super.NumeroProfesoresGrado()*3;
        
    }
    
    
    
}
