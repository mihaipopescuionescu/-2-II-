/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package alejandro.suárez.costa;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author w7ttzzn319nvpi000071
 */
public abstract class Grado implements IGrado {
    private String nombre;
    private HashMap<String,Estudiante> ConjuntoEstudiantes;
    private int numeroProfesores;
    private int numeroMaximoEstudiantes;

    public Grado() {
        String nombre=null;
        ConjuntoEstudiantes=new HashMap<String,Estudiante>();
        numeroProfesores=0;
        numeroMaximoEstudiantes=0;
    }

    public Grado(String nombre, int numeroMaximoEtudiantes) {
        setNombre(nombre);
        setNumeroMaximoEstudiantes(numeroMaximoEtudiantes);
        ConjuntoEstudiantes=new HashMap<String,Estudiante>();
        numeroProfesores=0;
    }

    public String getNombre() {
        return nombre;
    }

    public HashMap<String, Estudiante> getConjuntoEstudiantes() {
        return ConjuntoEstudiantes;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setConjuntoEstudiantes(HashMap<String, Estudiante> ConjuntoEstudiantes) {
        this.ConjuntoEstudiantes = ConjuntoEstudiantes;
    }

    public void setNumeroProfesores(int numeroProfesores) {
        this.numeroProfesores = numeroProfesores;
    }

    public void setNumeroMaximoEstudiantes(int numeroMaximoEtudiantes) {
        this.numeroMaximoEstudiantes = numeroMaximoEtudiantes;
    }
    

    public int getNumeroProfesores() {
        return numeroProfesores;
    }

    public int getNumeroMaximoEstudiantes() {
        return numeroMaximoEstudiantes;
    }
    public void DarAltaEstudiante(Estudiante estudiante) throws ExcepcionMaximoEstudiantes{
        int contador=0;
        for(Estudiante student:ConjuntoEstudiantes.values())
            contador++;
        if(contador>=getNumeroMaximoEstudiantes())
            throw new ExcepcionMaximoEstudiantes(estudiante,this);
        ConjuntoEstudiantes.put(estudiante.getNombre(), estudiante);
    }
    public void DarAltaEstudiante(String nombre,Grado grado){
        Estudiante estudiante=new Estudiante(nombre,grado);
        ConjuntoEstudiantes.put(nombre, estudiante);
    }
    public boolean EsEstudianteGrado(Estudiante estudiante){
        for(String keyset:ConjuntoEstudiantes.keySet())
            if(keyset.equals(estudiante))
                return true;
        return false; 
    }
    public boolean EsEstudianteGrado(String nombre){
        for (String keySet:ConjuntoEstudiantes.keySet())
            if(keySet.equals(nombre))
                return true;
        return false;
    }
    public ArrayList<Estudiante> ListaEstudianteAsignatura(String asignatura){
        ArrayList<Estudiante> listaEstudiantes=new ArrayList<>();
        for(Estudiante estudiante:ConjuntoEstudiantes.values())
            if(estudiante.getListaAsignaturas().containsKey(asignatura))
                listaEstudiantes.add(estudiante);
        return listaEstudiantes;
        
    } 
    public int NumeroProfesoresGrado(){
        int numeroEstudiantesGrado=this.NumeroEstudiantesGrado();
        numeroProfesores=(int)numeroEstudiantesGrado/30;
        return numeroProfesores;
    }
    public int NumeroEstudiantesGrado(){
        int contador=0;
        for(Estudiante estudiante:ConjuntoEstudiantes.values())
            contador++;
        return contador;
    }
}


//Grado es una clase abstracta que será la raiz de la jerarquia, la cual tendra
//2 ramas que serán ciencias y letras las cuales son tambien abstractas
// las cuales a su vez tendran 2 clases finales que seran los grados en si.

//Grado es abstracto porque no es una carrera en si, al igual que Ciencias y Letras
//las cuales son simplemente ramas de grado. Las clases finales seram Historia,
//Matematicas, Literatura e ingenieria informatica ya que estas si que son una 
//carrera, un grado en concreto, algo tangible.