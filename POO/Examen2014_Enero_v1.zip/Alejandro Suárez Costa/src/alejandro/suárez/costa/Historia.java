/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package alejandro.suárez.costa;

/**
 *
 * @author w7ttzzn319nvpi000071
 */
public final class Historia extends Letras{

    public Historia() {
        super();
    }
    public Historia(String nombre,int numeroEstudiantes){
        super(nombre,numeroEstudiantes);
    }
    
    @Override
    public int NumeroProfesoresGrado(){
        return super.NumeroProfesoresGrado()*5;
        
    }
    
}
