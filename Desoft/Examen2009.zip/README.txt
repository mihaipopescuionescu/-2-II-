El archivo son flashcards de Anki (aplicación para web/móvil) con todo el temario de DISO, más que suficiente para preparar el temario.
Importar en Anki. 

| 27/05/2024, con <3 por @cese. ¡ánimo! |