#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>         // Función open()
#include<unistd.h>        // Funciones read(), write()
#include<sys/wait.h>      // waitpid

/*
 * En este programa se realiza un experimento de lectura y escritura de dos
 * ficheros compartidos por un padre y su(s) hijo(s), con el objetivo de
 * observar situaciones de carreras críticas.
 */

int leer_escribir();

// Variables globales:
int fichero1, fichero2;
char caracter;            // Carácter leído de los ficheros

int main(int argc, char* argv[]){
    int status;     // Estatus de la función waitpid
    int par;        // Resultado del fork
    int N = 1;      // Número de hijos (1 por defecto)
    int i;

    // Si argc == 4, se ha indicado un número de procesos determinado
    if (argc == 4) N = atoi(argv[3]);   
    else if (argc != 3) exit(EXIT_FAILURE);   // Ni 3 ni 4 argumentos

    // Abrimos un archivo (0) con permisos r--r--r-- (444)
    fichero1 = open(argv[1], 0444);
    // Abrimos el segundo archivo (0) con permisos rw-rw-rw- (666)
    fichero2 = open(argv[2], 0666);

    if (fichero1 == -1) printf("\nError al abrir el fichero 1\n");
    if (fichero2 == -1) printf("\nError al abrir el fichero 2\n");

    for (i = 0; i < N; i++){
        par = fork();               // Creamos un nuevo proceso
        if (par == 0) break;        // Los hijos no crean más hijos
    }

    // Padre e hijo intentan leer de fichero1 y escribir en fichero2
    // (El hijo también tiene acceso a los ficheros, ya que es una copia
    // exacta de su padre)
    leer_escribir();

    // El hijo finaliza
    if (par == 0) exit(EXIT_SUCCESS);

    // El padre espera por el hijo y luego cierra los ficheros
    waitpid(-1, &status, 0);
    close(fichero1);
    close(fichero2);

    printf("Cerrando programa...\n\n");

    exit(EXIT_SUCCESS);
}

int leer_escribir(){
    for (;;){   // Bucle infinito (hasta que se termine de leer fichero1)
        // Tratamos de leer 1 byte (1 char) y lo guardamos en caracter
        // read devuelve el número de bytes que ha leído
        if (read(fichero1, &caracter, 1) != 1)
            return(0);      // Error o se ha llegado al final del archivo

        write(fichero2, &caracter, 1);  // Escribimos el carácter leído
    }
}
