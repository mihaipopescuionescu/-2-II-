#include<stdio.h>
#include<stdlib.h>

/*
 * Este programa compara 2 ficheros y cuenta el número de caracteres
 * en los que difieren.
 */

int main(int argc, char* argv[]){
    FILE *flectura, *fescritura;     // Ficheros de lectura y escritura
    FILE *fresultados;               // Fichero de escritura de los resultados
    char c_lect, c_escr;             // Caracteres de cada fichero
    int cuenta = 0;                  // Número de caracteres diferentes
    int tamanho = 0;                 // Contador del tamaño de los ficheros

    if (argc != 3) exit(EXIT_FAILURE);

    // Abrimos ambos ficheros en modo de lectura
    if ((flectura = fopen(argv[1], "r")) == NULL){
        printf("Error en la apertura del primer archivo\n");
        exit(EXIT_FAILURE);
    }

    if ((fescritura = fopen(argv[2], "r")) == NULL){
        printf("Error en la apertura del segundo archivo\n");
        exit(EXIT_FAILURE);
    }

    // Por comodidad, no pasamos resultados.txt por línea de comandos
    // Abrimos resultados.txt en modo append
    if ((fresultados = fopen("resultados_20.txt", "a")) == NULL){
        printf("Error en la apertura del archivo de resultados\n");
        exit(EXIT_FAILURE);
    }

    while(1){    // Bucle infinito (hasta llegar al final de un fichero)
        // Leemos un cáracter de cada fichero
        c_lect = fgetc(flectura);
        c_escr = fgetc(fescritura);

        // Si se ha llegado al final de alguno, cortamos el bucle
        if (c_lect == EOF || c_escr == EOF) break;

        if (c_lect != c_escr) cuenta++;    // Carácter diferente
        tamanho++;
    }

    // Se muestra el resultado por pantalla y se añade al fichero fresultados
    printf("Tamaño del archivo: %d\n", tamanho);
    printf("Número de caracteres diferentes: %d\n", cuenta);
    fprintf(fresultados, "Tamaño: %d. Diferencias: %d\n", tamanho, cuenta);

    printf("Cerrando programa...\n\n");

    exit(EXIT_SUCCESS);
}
